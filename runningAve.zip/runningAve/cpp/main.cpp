#include <iostream>
#include "ossie/ossieSupport.h"

#include "runningAve.h"
int main(int argc, char* argv[])
{
    runningAve_i* runningAve_servant;
    Component::start_component(runningAve_servant, argc, argv);
    return 0;
}

