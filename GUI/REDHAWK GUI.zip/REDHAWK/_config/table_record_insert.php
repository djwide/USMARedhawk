<?php

include ("../_includes/_connect.php");

// Users ***************************************************************************

$sql = "DROP TABLE if exists users" ;

mysqli_query($con, $sql);

$sql = "CREATE TABLE users (

id int(32) unsigned auto_increment NOT NULL,
usertype varchar(16),
username varchar(128),
first_name varchar(32),
last_name varchar(32),
password varchar(256),

PRIMARY KEY (id, usertype)

)";

mysqli_query($con, $sql) or die (mysqli_error($con));;

echo "<br>USERS table created ...<br>";

// Data ****************************************************************************

// Transmitters

$sql = "DROP TABLE if exists receivers" ;

mysqli_query($con, $sql);

// Create table and allow each field up to 512 variable characters to be used for each database (db) record

$sql = "CREATE TABLE receivers (

id int(32) unsigned auto_increment NOT NULL,
time TIMESTAMP NULL,
sensorNum INT(1) NOT NULL,
db DECIMAL(6,3) NOT NULL,
frequency DECIMAL(6,3) NOT NULL,
wavelength DECIMAL (6,3) NOT NULL,
sensorlatitude DECIMAL(9,6) NOT NULL,
sensorlongitude DECIMAL(9,6) NOT NULL,
lob INT(3) NOT NULL,
PRIMARY KEY (id)
)";

mysqli_query($con, $sql) or die (mysqli_error($con));

echo "<br>RECEIVERS table created ...<br>";

// Receivers

$sql = "DROP TABLE if exists target" ;

mysqli_query($con, $sql);

$sql = "CREATE TABLE target (
targetid int(32) unsigned auto_increment NOT NULL,
time TIMESTAMP NULL,
frequency DECIMAL(6,3) NOT NULL,
latitude DECIMAL(9,6) NOT NULL,
longitude DECIMAL(9,6) NOT NULL,
PRIMARY KEY (targetid)
)";

mysqli_query($con, $sql) or die (mysqli_error($con));

echo "<br>TARGET table created ...<br>";

// End Table Creation ---------------------------------------------------------------------------
// Automatically insert miscellaneous test data into table for project design & testing purposes.

// USERS Table

$sql = "INSERT INTO users (id, usertype, username, first_name, last_name, password) VALUES ('1', '1', 'brendon.palowitch@usma.edu', 'Brendon', 'Palowitch', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3')";
mysqli_query($con, $sql) or die (mysqli_error($con));

$sql = "INSERT INTO users (id, usertype, username, first_name, last_name, password) VALUES ('2', '1', 'michael.chiu@usma.edu', 'Michael', 'Chiu', 'b3a8e0e1f9ab1bfe3a36f231f676f78bb30a519d2b21e6c530c0eee8ebb4a5d0')";
mysqli_query($con, $sql) or die (mysqli_error($con));

echo "<br>USER table populated ...<br>";

// Receivers Table

$sql = "INSERT INTO receivers (id, time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob) VALUES ('1', '2016-01-29 10:30:30', '1', '10.000', '462.6375', '123.456', '41.395449', '-73.956007', '128')";
mysqli_query($con, $sql);

$sql = "INSERT INTO receivers (id, time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob) VALUES ('2', '2016-01-29 10:30:30', '2', '10.000', '462.6375', '123.456', '41.39147', '-73.95479', '128')";
mysqli_query($con, $sql);

$sql = "INSERT INTO receivers (id, time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob) VALUES ('3', '2016-01-29 10:30:30', '3', '10.000', '462.6375', '123.456', '41.39411', '-73.95943', '128')";
mysqli_query($con, $sql);

echo "<br>RECEIVERS table populated ...<br>";

// Target Table;

$sql = "INSERT INTO target (targetid, time, frequency, latitude, longitude) VALUES('1', '2016-01-29 10:30:30', '462.6370', '41.393660', '-73.956667')";
mysqli_query($con, $sql);

$sql = "INSERT INTO target (targetid, time, frequency, latitude, longitude) VALUES('2', '2016-01-29 10:30:30', '462.6375', '41.394038', '-73.957399')";
mysqli_query($con, $sql);

$sql = "INSERT INTO target (targetid, time, frequency, latitude, longitude) VALUES('3', '2016-01-29 10:30:30', '462.6380', '41.393152', '-73.955822')";
mysqli_query($con, $sql);

echo "<br>TARGET table populated ...<br>";

?>
