<?php session_start();

// Ensure proper login credentials have been provided before displaying this page

 	$requestor = '';

	if 		(isset($_SESSION['admin']))	{
			$requestor = $_SESSION['admin'];
	}

	if		($requestor) {

// User validation completed

require ("../modules/add_record.php");

?>

<head>

<link rel="stylesheet" type="text/css" href="../site.css">

</head>

<form name="form" method="post" >

<div align="center">

<table cellpadding="5px" style="width: 90%; border-spacing: 5px">

	<tr><td colspan="2"><span style="font-weight: bold; font-size: 14pt">Add Target Frequencies</span></td></tr>

</table>

</div>

<div align="center">

<form action="add_record.php" method="post">

<table style="width: 90%; padding: 5px; border-spacing: 15px;">
	<tr>
		<td style="width: 150px;">Time</td>
		<td><input name="time" class="box200" tabindex="1" value="<?=$time;?>"></td>
	</tr>
    <tr>
		<td>Frequency</td>
		<td><input name="frequency" class="box200" tabindex="3" value="<?=$frequency;?>"></td>
	</tr>
    <tr>
		<td>Latitude</td>
		<td><input name="latitude" class="box200" tabindex="4" value="<?=$latitude;?>"></td>
	</tr>
	<tr>
		<td>Longitude</td>
		<td><input name="longitude" class="box200" tabindex="5" value="<?=$longitude;?>"></td>
	</tr>
    <tr>
        <td></td>
          <td>
               <input type="submit" name="save" class="btn_acp" style="margin-right: 15px;" value="Save Entries" />
          &nbsp;
               <input type="submit" name="done" class="btn_acp" style="margin-right: 15px;" value="Done" />
          </td>
     </tr>
</table>

</form>

</div>

</form>

<?php } else { echo "<br><br><center>You must login to view this page.</center>" ; }?>