<?php

$errormsg = null;

include ("../modules/login.php");

?>

<head>

     <link rel="stylesheet" type="text/css" href="../site.css">

</head>

<body>

<form method="post">

<div align="center">

<table style="border-spacing: 15px; margin-top: 50px">
  <tr>
     <td style="width: 70px"></td>
     <td style="height: 30px; font-weight: bold;font-size: 14pt">Secure User Login</td>
  </tr>
  <tr>
     <td>Email:</td>
     <td><input class="box250" name="myusername" type="text" id="myusername" value="brendon.palowitch@usma.edu" /></td>
  </tr>
  <tr>
     <td>Password:</td>
     <td><input class="box250" name="mypassword" type="text" id="mypassword" value="123" /></td>
  </tr>
  <tr>
     <td></td>
     <td><input name="submit" class="btn_acp" type="submit" value="Login" style="margin-right: 10px;" /></td>
  </tr>
  <tr>
     <td></td>
     <td><font color="#FF0000"><?=$errormsg;?></font></td>
  </tr>
  <tr>
     <td colspan="2" style="text-align: center"></td></tr>
  <tr>
     <td></td>
     <td>brendon.palowitch@usma.edu</td></tr>
  <tr>
     <td></td>
     <td>michael.chiu@usma.edu</td>
  </tr>
</table>

</div>

</form>

</body>
</html>