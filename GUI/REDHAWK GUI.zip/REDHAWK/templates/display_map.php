<?php session_start();

?>

<!DOCTYPE HTML>

<html>

<head>

<script src="http://maps.googleapis.com/maps/api/js"></script>

<script>

function initialize() {

  var mapProp = {
    center:new google.maps.LatLng(<?=$_POST['latitude'];?>, <?=$_POST['longitude'];?>),
    zoom:18,
    mapTypeId:google.maps.MapTypeId.HYBRID
  };

  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

  var marker1 = new google.maps.Marker({
      position: {lat: <?=$_POST['latitude'];?> , lng: <?=$_POST['longitude'];?> },
      title: "Target ID: <?=$_POST['targetid'];?>" +
            "\nFrequency: <?=$_POST['frequency'];?>" +
            "\nLatitude: <?=$_POST['latitude'];?>" +
            "\nLongitude: <?=$_POST['longitude'];?>"
  });

  var circle1 = new google.maps.Circle({
    center: new google.maps.LatLng(<?=$_POST['latitude'];?> , <?=$_POST['longitude'];?>),
    radius:20,
    strokeColor:"#FF0000",
    strokeOpacity:0.8,
    strokeWeight:2
  });

  marker1.setMap(map);
  circle1.setMap(map);

}

google.maps.event.addDomListener(window, 'load', initialize);

</script>

</head>

<body>
<div id="googleMap" style="width:99vw;height:98vh;"></div>
</body>

</html>

<!--http://www.w3schools.com/googleapi/google_maps_basic.asp-->