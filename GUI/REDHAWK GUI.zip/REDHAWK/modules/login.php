<?php session_start();

include ("../_includes/_connect.php");

// set undefined variable(s)

$good = null;
$no_match = null;
$errormsg = "";
$affiliate_unauthorized = "";


// Set Date & Timezone

	date_default_timezone_set("America/New_York");
	$unix_time = date(time());


// Set variables if Login form is submitted

 	if (isset($_POST['submit']) && !empty($_POST['submit']))	{

		// username and password sent from form

		$myusername= isset($_POST['myusername']) ? $_POST['myusername'] : null;
		$mypassword= isset($_POST['mypassword']) ? $_POST['mypassword'] : null;

		// To protect MySQL injection (more detail about MySQL injection)

		$myusername = stripslashes($myusername);
		$mypassword = stripslashes($mypassword);
		$myusername = mysqli_real_escape_string($con, $myusername);
		$mypassword = mysqli_real_escape_string($con, $mypassword);

		// Encrypt the password

	  	$mypassword = hash('sha256', $mypassword);

		// Check db for existing user

		$query = "SELECT id, usertype, username
                    FROM users
                    WHERE username ='$myusername' AND password='$mypassword' ";

		$result = mysqli_query($con, $query) or die (mysqli_error($con));

		$count = mysqli_num_rows($result);

			if ($result && $count == 1) {

				$row = mysqli_fetch_object($result);

				$user_type = $row -> usertype;
				$user_id = $row -> id;


// Define UserTypes and where they go after login ...

			// ADMIN

			if 			($user_type == 1)	{

							if (empty($_SESSION['admin']))

								$_SESSION['admin'] = $myusername;

								header("location:../modules/show_data_1.php ");

			}

}  // Finish -> if ($result && $count == 1)


// Create error message for incorrect credentials

		else {

			$errormsg = "" ;
			$errormsg = "Incorrect Login. Please try again.";
		}

}	// Closes -> if ($_POST['submit']){


// Close db

mysqli_close($con);

?>