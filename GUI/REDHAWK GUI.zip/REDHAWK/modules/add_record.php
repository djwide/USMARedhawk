<?php

include ("../_includes/_connect.php");

// set variables

$time = null;
$frequency = null;
$latitude = null;
$longitude = null;


// Leave the Add Record page if user clicks 'done' button

     if(isset($_POST['done'])) {

          header("Location: ../modules/show_data_1.php");
          exit();
	}

// Protect db from SQL injection through form

	if (isset($_POST["save"]) && !empty($_POST["time"]))	{

          $time 	        = mysqli_real_escape_string($con, $_POST['time']);
          $frequency        = mysqli_real_escape_string($con, $_POST['frequency']);
          $latitude	= mysqli_real_escape_string($con, $_POST['latitude']);
          $longitude  = mysqli_real_escape_string($con, $_POST['longitude']);

// define SET fields for entry into db

	$set_fields =

        "time           = '$time',
       	frequency		= '$frequency',
		latitude	= '$latitude',
		longitude	= '$longitude',";

// insert entries into db

	$query = "SELECT * FROM target";
	$results = mysqli_query($con, $query) or die (mysqli_error($con));

	    $sql = "INSERT target SET ".$set_fields." " ;
    	mysqli_query($con, $sql) or die (mysqli_error($con));

	}

// close db

	mysqli_close($con);

?>