<?php session_start();

// Connect to db

include("../_includes/_connect.php");

// Clear unknown variables

$default_order_ascending = null;

// Ensure user is logged in. Credentialed users are established in login.php

 	$requestor = '';

	if   (isset($_SESSION['admin'])) {

	     $requestor = $_SESSION['admin'];
	}

	if		($requestor) {


//  Action to take if user clicks the 'Add New Record' button on results page

	if(isset($_POST['add_new_record'])) {

          header("Location: ../templates/add_record.php");
          exit();
	}

// Action to take if user clicks the 'logout' button on results page

     if   (isset($_POST['logout'])) {

		session_destroy();
          header('Location: ../templates/login.php');
	}

// get sorting information, so we can sort output to user's liking;

	$sort_order = @ $_GET['sort_order'];
	$direction = @ $_GET['direction'];

// Action taken if user clicks the 'Default Sort' button at bottom of results page

	if(isset($_POST['exit_sort'])) {

		header('Location: show_data_1.php');
		exit;
	}

// Action taken if user clicks the record's MAP button

     if(isset($_POST['mapit'])) {

          header("Location: ../templates/display_map.php");
          exit();
	}

// Prepare Results for display in table: Query db records and order them by ID & ASCending by DEFAULT (see: else statement below).

     if ($sort_order)	{

     $query1 = "SELECT targetid, time, frequency, latitude, longitude

   		     FROM target
               ORDER BY ".$sort_order." ".$direction." limit 3";

     $results = mysqli_query($con, $query1) or die (mysqli_error($con));

     } else {

	$query2 = "SELECT targetid, time, frequency, latitude, longitude

   		     FROM target
               ORDER BY targetid DESC limit 3";

     $results = mysqli_query($con, $query2) or die (mysqli_error($con));

     }

echo

// Create the table and header row, which data will be displayed in BEFORE the repeating WHILE command sine we don't want to repeat the header.

"<link rel=\"stylesheet\" type=\"text/css\" href=\"../site.css\">".

"<form method=\"post\">".
     "<table cellpadding=\"5\" align=\"center\">".
          "<tr>
               <td align=\"center\" colspan=\"2\"><span style=\"font-weight: bold; font-size: 14pt; \">THE REDHAWK ENDEAVOR</span></td></tr>".
          "<tr>".
               "<td align=\"center\" colspan=\"2\"><span style=\"color: #0033CC\">Click column headers to sort data in descending order</span></td></tr>".
          "<tr>".
               "<td align=\"center\">".
                    "<input type=\"submit\" name=\"add_new_record\" class=\"btn_acp\" style=\"margin-right: 10px\" value=\"Add New Target Frequency\" />".
                    "<input type=\"submit\" name=\"exit_sort\" class=\"btn_acp\" style=\"margin-right: 10px\" value=\"Default Sort Order\" />".
                    "<input type=\"submit\" name=\"logout\" class=\"btn_acp\" value=\"Logout\" />".
               "</td>".
          "</tr>".
     "</table>".
"</form>".

"<table cellpadding=\"5\" cellspacing=\"5\" align=\"center\" style=\"margin-top: -50px;\">".
     "<tr>".
          "<td width=\"100px\" style=\"font-weight: bold; text-align: center\"><a href=\"show_data_1.php?sort_order=targetid&direction=desc\">Target ID</a></td>".
          "<td width=\"150px\" style=\"font-weight: bold; text-align: center\"><a href=\"show_data_1.php?sort_order=time&direction=asc\">Time</a></td>".
          "<td width=\"100px\" style=\"font-weight: bold; text-align: center\"><a href=\"show_data_1.php?sort_order=frequency&direction=desc\">Freq.</a></td>".
          "<td width=\"100px\" style=\"font-weight: bold; text-align: center\"><a href=\"show_data_1.php?sort_order=latitude&direction=asc\">Lat.</a></td>".
          "<td width=\"100px\" style=\"font-weight: bold; text-align: center\"><a href=\"show_data_1.php?sort_order=longitude&direction=asc\">Lon.</a></td>".
          "<td width=\"100px\" style=\"font-weight: bold; text-align: center\">Location</td>".
     "</tr>";

// Run the repeating WHILE statement for the purpose of retrieving all records

     while ($row = mysqli_fetch_array($results))	{

// Begin iterating through all data stored in transmission table and display it line by line in the table created above

echo
"<br />".
"<form method=\"post\" action=\"../templates/display_map.php\">".
"<td width=\"100px\" style=\"text-align: center\">".$row['targetid']."<input type=\"hidden\" name=\"targetid\" value=\"".$row['targetid']."\"/></td>".
"<td width=\"150px\" style=\"text-align: center\">".$row['time']."</td>".
"<td width=\"100px\" style=\"text-align: center\">".$row['frequency']."<input type=\"hidden\" name=\"frequency\" value=\"".$row['frequency']."\"/></td>".
"<td width=\"100px\" style=\"text-align: center\">".$row['latitude']."<input type=\"hidden\" name=\"latitude\" value=\"".$row['latitude']."\"/></td>".
"<td width=\"100px\" style=\"text-align: center\">".$row['longitude']."<input type=\"hidden\" name=\"longitude\" value=\"".$row['longitude']."\"/></td>".
"<td width=\"100px\" align=\"center\"><input type=\"submit\" name=\"mapit\" class=\"btn_acp\" value=\"Map\" /></td>".
"</tr>".
"</form>";

} // End the HTML table after all iterations of data have been presented to user

// Close table

echo "</table>";

     $query3 = "SELECT targetid, time, frequency, latitude, longitude FROM target ORDER BY targetid ASC ";
     $results2 = mysqli_query($con, $query3) or die (mysqli_error($con));

     $query4 = "select time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob from receivers where sensorNum=1 and time = (select max(time) from receivers where sensorNum=1)";
     $results3 = mysqli_query($con, $query4) or die (mysqli_error($con));

     $query5 = "select time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob from receivers where sensorNum=2 and time = (select max(time) from receivers where sensorNum=2)";
     $results4 = mysqli_query($con, $query5) or die (mysqli_error($con));

     $query6 = "select time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob from receivers where sensorNum=3 and time = (select max(time) from receivers where sensorNum=3)";
     $results5 = mysqli_query($con, $query6) or die (mysqli_error($con));

     $query7 = "SELECT time, sensorNum, db, frequency, wavelength, sensorlatitude, sensorlongitude, lob FROM receivers";
     $results6 = mysqli_query($con, $query4) or die (mysqli_error($con));

?>

<html>
<head>

<script src="http://maps.googleapis.com/maps/api/js"></script>

<script>

function initialize() {

    var mapProp = {
    center:new google.maps.LatLng(41.393403, -73.956208),
    zoom:17,
    mapTypeId:google.maps.MapTypeId.HYBRID
};

var map=new google.maps.Map(document.getElementById("googleMap"), mapProp);

<?php

    while ($row2 = mysqli_fetch_array($results2))	{

?>
        var marker<?php echo $row2['targetid'];?> = new google.maps.Marker({
           position: {lat: <?php echo $row2['latitude'];?> ,
                      lng: <?php echo $row2['longitude'];?> },
            title: "Target ID: " + "<?php echo $row2['targetid'];?>" });

        var circle<?php echo $row2['targetid'];?> = new google.maps.Circle({
            center: new google.maps.LatLng(<?php echo $row2['latitude'];?> ,
                <?php echo $row2['longitude'];?>),
            radius:20,
            strokeColor:"#FF0000",
            strokeOpacity:0.8,
            strokeWeight:2,
            title: "TargetID: " + "<?php echo $row2['targetid'];?>" });

            marker<?php echo $row2['targetid'];?>.setMap(map);
            circle<?php echo $row2['targetid'];?>.setMap(map);

<?php
    }

    while ($row3 = mysqli_fetch_array($results3)) {

?>
        var sensor1 = new google.maps.Marker({
            position: {lat: <?php echo $row3['sensorlatitude'];?>,
                        lng: <?php echo $row3['sensorlongitude'];?> },
            title: "Sensor Num: 1" +
                    "\nLatitude: " + "<?php echo $row3['sensorlatitude'];?>" +
                    "\nLongitude: " + "<?php echo $row3['sensorlongitude'];?>" +
                    "\nPower: " + "<?php echo $row3['db'];?>" +
                    "\nFrequency: " + "<?php echo $row3['frequency'];?>" +
                    "\nWavelength: " + "<?php echo $row3['wavelength'];?>" +
                    "\nLoB: " + "<?php echo $row3['lob'];?>",
            icon: '../images/antenna.png'});

            sensor1.setMap(map);

<?php
    }
    while ($row4 = mysqli_fetch_array($results4)) {

?>
        var sensor2 = new google.maps.Marker({
            position: {lat: <?php echo $row4['sensorlatitude'];?>,
                        lng: <?php echo $row4['sensorlongitude'];?> },
            title:  "Sensor Num: 2" +
                    "\nLatitude: " + "<?php echo $row4['sensorlatitude'];?>" +
                    "\nLongitude: " + "<?php echo $row4['sensorlongitude'];?>" +
                    "\nPower: " + "<?php echo $row4['db'];?>" +
                    "\nFrequency: " + "<?php echo $row4['frequency'];?>" +
                    "\nWavelength: " + "<?php echo $row4['wavelength'];?>" +
                    "\nLoB: " + "<?php echo $row4['lob'];?>",
            icon: '../images/antenna.png'});

            sensor2.setMap(map);

<?php
    }
        while ($row5 = mysqli_fetch_array($results5)) {

?>
        var sensor3 = new google.maps.Marker({
            position: {lat: <?php echo $row5['sensorlatitude'];?>,
                        lng: <?php echo $row5['sensorlongitude'];?> },
            title: "Sensor Num: 3" +
                    "\nLatitude: " + "<?php echo $row5['sensorlatitude'];?>" +
                    "\nLongitude: " + "<?php echo $row5['sensorlongitude'];?>" +
                    "\nPower: " + "<?php echo $row5['db'];?>" +
                    "\nFrequency: " + "<?php echo $row5['frequency'];?>" +
                    "\nWavelength: " + "<?php echo $row5['wavelength'];?>" +
                    "\nLoB: " + "<?php echo $row5['lob'];?>",
            icon: '../images/antenna.png'});

            sensor3.setMap(map);

<?php
    }

?>

}

google.maps.event.addDomListener(window, 'load', initialize);

</script>

</head>

<body>
<div align="center">
<div id="googleMap" style="margin-top:10px;width:window.innerwidth; height:70vh;"></div>
</div>
</body>
</html>

<!--http://www.w3schools.com/googleapi/google_maps_basic.asp-->

<?php

// Close database

     mysqli_close($con);

} else { echo "<br><br><center>You must login to view this page.</center>" ; }

?>