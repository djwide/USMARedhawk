<?php

$con = mysqli_connect("192.168.1.54","webserve","redhawk","RHtest");

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

?>