Individual Citations concerning the PHP/HTML Code are commented in the specific page.

For the entirety of the GUI, I spoke with Michael Dirk Palowitch. He assisted me via telephone, video conference,
and electronic chat. The typical method for the GUI development follows:
	1. I find a new design problem
	2. I discuss the problem with Dirk Palowitch
	3. Dirk plans a way to complete the problem and walks me through the syntax and coding design.
	4. I refine the GUI to meet intent
Dirk Palowitch aided a lot in the development of this GUI and often coded certain parts himself to aid in my learning.