/**************************************************************************

    This is the component code. This file contains the child class where
    custom functionality can be added to the component. Custom
    functionality to the base class can be extended here. Access to
    the ports can also be done from this class

**************************************************************************/

#include "runningAve2.h"

PREPARE_LOGGING(runningAve2_i)

runningAve2_i::runningAve2_i(const char *uuid, const char *label) :
    runningAve2_base(uuid, label)
{
    // Avoid placing constructor code here. Instead, use the "constructor" function.

}

runningAve2_i::~runningAve2_i()
{
}

void runningAve2_i::constructor()
{
    /***********************************************************************************
     This is the RH constructor. All properties are properly initialized before this function is called 
    ***********************************************************************************/
}

int runningAve2_i::serviceFunction()
{
	bulkio::InFloatPort::dataTransfer *tmp = input->getPacket(bulkio::Const::BLOCKING);

	if (not tmp) { // No data is available
		return NOOP;
	}
	float THRESHOLD= .1;//change
	float recentAve=0;
	float runningAverage=0;
	float poppedVal=0;
	float recentInpTotal=0;

	std::vector<float>* intermediate = (std::vector<float>*) &(tmp->dataBuffer);

	for (unsigned int i=0; i<tmp->dataBuffer.size()/2-1; i++) {
		recentInpTotal += (*intermediate)[i];//adds allocator to intermediate
	}
	//std::cout<< "a";
	//(*intermediate).size();
	recentAve= recentInpTotal/(*intermediate).size();
	//get average
	//add average to running average
	std::queue<float> aveQueue;
	aveQueue.push(recentAve);
	int size= aveQueue.size();
	if(aveQueue.size() > 99){
		poppedVal= aveQueue.front();
		aveQueue.pop();
		runningAverage = (recentAve-poppedVal + (size-1)*runningAverage)/(size-1);
	}//alternate cases for full queue?
	else{
		runningAverage = (recentAve + (size-1)*runningAverage)/(size);
	}
	if (runningAverage> THRESHOLD){
		runningAve_struct message;
		message.ave= runningAverage;
		message.wavelength= 462.52;
		this-> outMess-> sendMessage(message);
	}
	return NOOP;
}

