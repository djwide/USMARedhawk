#!/usr/bin/env python
#
#
# AUTO-GENERATED
#
# Source: dbwriter.spd.xml
from ossie.resource import start_component
import logging
import MySQLdb as mdb
import sys
import time


from dbwriter_base import *

class dbwriter_i(dbwriter_base):
    """<DESCRIPTION GOES HERE>"""
    def initialize(self):
        """
        """
        dbwriter_base.initialize(self)
        self.count = 0
        print "connecting to db..."
        try:
            self.con = mdb.Connect('192.168.1.54', 'webserve', 'redhawk', 'RHtest')
            print "success"
            self.cursor = self.con.cursor()
        except mdb.Error, e:
            print "fail /n"
            print "Error " + str(e.args[0]) + ": " + str(e.args[1])
            sys.exit(1)
        # TODO add customization here.
        
    def constructor(self):
        self.port_dataFloat_in.registerMessage("fromUpToInsert", dbwriter_base.FromUpToInsert, self.messageReceived)  
        self.port_dataFloat_in2.registerMessage("fromCentToDB", dbwriter_base.FromCentToDB, self.messageReceived2)

    def process(self):
        """
           
        """

        # TODO fill in your code here
        
        # NOTE: You must make at least one valid pushSRI call'''
        return NOOP
    
    def messageReceived(self, msgId, msgData):
        self._log.info("messageReceived *************************")
        self._log.info("messageReceived msgId " + str(msgId))
        self._log.info("messageReceived msgData " + str(msgData)) 
        data= [msgData.X, msgData.Y]
        
        if data == None:
            return NOOP
    
        #YYYMMDDHHMMSS = datetime
        #f = open("rhtest.txt", "wr")
        insertString ='462.52, '+ str(data[0]) + ", " +str(data[1])
        logging.info(insertString)
#        self.cursor.execute("INSERT INTO TestTable(time, dp1, dp2, dp3, dp4, dp5, dp6, dp7, dp8, dp9, dp10, count) VALUES(" + insertString[0:len(insertString) - 3])
        self.cursor.execute("INSERT INTO processed(frequency, targetlatitude, targetlongitude) VALUES(" + insertString +");") 
        
        
    def messageReceived2(self, msgId, msgData):
        self._log.info("messageReceived *************************")
        self._log.info("messageReceived msgId " + str(msgId))
        self._log.info("messageReceived msgData " + str(msgData))
        
        data= [1, msgData.ave, msgData.freq, -msgData.wave, msgData.lat,  msgData.long, msgData.aoa, msgData.comp]
        
        if data == None:
            return NOOP
    
        insertString= '20160322104500, '
        #YYYMMDDHHMMSS = datetime
        #f = open("rhtest.txt", "wr")
        for i in range(0, 6):
            insertString += str(data[i]) + ", "
        insertString += str(data[7])
        logging.info(insertString)
#        self.cursor.execute("INSERT INTO TestTable(time, dp1, dp2, dp3, dp4, dp5, dp6, dp7, dp8, dp9, dp10, count) VALUES(" + insertString[0:len(insertString) - 3])
        self.cursor.execute("INSERT INTO transmissions(time, sensorNum1, db, frequency, wavelength, latitude, longitude, angle) VALUES(" + insertString +");") 
#INSERT INTO TestTable(vals) VALUES(vals)

if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    logging.debug("Starting Component")
    print "hello"
    start_component(dbwriter_i)
    print "test"
