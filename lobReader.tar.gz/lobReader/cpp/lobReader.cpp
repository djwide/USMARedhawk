/**************************************************************************

    This is the component code. This file contains the child class where
    custom functionality can be added to the component. Custom
    functionality to the base class can be extended here. Access to
    the ports can also be done from this class

**************************************************************************/

#include "lobReader.h"

PREPARE_LOGGING(lobReader_i)

lobReader_i::lobReader_i(const char *uuid, const char *label) :
    lobReader_base(uuid, label)
{
    // Avoid placing constructor code here. Instead, use the "constructor" function.

}

lobReader_i::~lobReader_i()
{
}

void lobReader_i::constructor()
{
    /***********************************************************************************
     This is the RH constructor. All properties are properly initialized before this function is called 
    ***********************************************************************************/
}

        

int lobReader_i::serviceFunction()
{
	Compass_struct message;
	message.aoa= 888;
	LOG_DEBUG(lobReader_i, message.compass);
	this-> outMess-> sendMessage(message);
    return NOOP;
}

