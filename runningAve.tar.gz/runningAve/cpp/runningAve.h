#ifndef RUNNINGAVE_I_IMPL_H
#define RUNNINGAVE_I_IMPL_H

#include "runningAve_base.h"

class runningAve_i : public runningAve_base
{
    ENABLE_LOGGING
    public:
        runningAve_i(const char *uuid, const char *label);
        ~runningAve_i();

        void constructor();

        int serviceFunction();
};

#endif // RUNNINGAVE_I_IMPL_H
