#!/usr/bin/env python
#
#
# AUTO-GENERATED
#
# Source: centralNodeReceiver.spd.xml
from ossie.resource import start_component
import logging

from centralNodeReceiver_base import *
#TODO
#Keep most current of each incoming node.  When all have changed/ enough time has passed send the requisite info to the updater
class centralNodeReceiver_i(centralNodeReceiver_base):
    """<DESCRIPTION GOES HERE>"""
    def constructor(self):
        self.port_message_in.registerMessage("accumMess", centralNodeReceiver_base.AccumMess, self.messageReceived)
        self.state= [False, False, False]
        #most recent readings
        self.ave1=0
        self.ave2=0
        self.ave3=0
        self.lob1=0
        self.lob2=0
        self.lob3=0
    #make three parellel heaps sorted by time.  
    
    
    def messageReceived(self, msgId, msg):
        message= centralNodeReceiver_base.FromCentToUpdate()
        logging.info(msg.aveA)
        if(msg.nodeID==1):
            self.state[0]=True
            self.ave1= msg.aveA
            self.lob1= msg.aoaA
        if(msg.nodeID==2):
            self.state[1]=True
            self.ave2= msg.aveA
            self.lob2= msg.aoaA
        if(msg.nodeID==3):
            self.state[2]=True
            self.ave3= msg.aveA
            self.lob3= msg.aoaA
        
        if(self.state==[True,True,True]):
            message.aveUp1=self.ave1
            message.aveUp2=self.ave2
            message.aveUp3=self.ave3
            message.lobUp1=self.lob1
            message.lobUp2=self.lob2
            message.lobUp3=self.lob3           
            self.port_toUpdate.sendMessage(message)
            self.state= [False, False,False]
        
        message2= centralNodeReceiver_base.FromCentToDB()
        #message2.ave=55.0
        message2.lat= 99.0
        message2.long= 99.0
        message2.freq= 99.0
        message2.aoa= 99.0
        self.port_toDB.sendMessage(message2)
          
    def process(self):
        message= centralNodeReceiver_base.FromCentToUpdate()
        #logging.info("================")
        message.aveUp1=55.0
        message.lobUp1= 99.0
        message.aveUp2=55.0
        message.lobUp2= 99.0
        message.aveUp3=55.0
        message.lobUp3= 99.0
        self.port_toUpdate.sendMessage(message)
        
        
        message2= centralNodeReceiver_base.FromCentToDB()
        #message2.ave=55.0
        message2.lat= 99.0
        message2.long= 99.0
        message2.freq= 99.0
        message2.aoa= 99.0
        self.port_toDB.sendMessage(message2)
        return NOOP

  
if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    logging.debug("Starting Component")
    start_component(centralNodeReceiver_i)

