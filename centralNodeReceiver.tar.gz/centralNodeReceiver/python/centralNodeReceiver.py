#!/usr/bin/env python
#
#
# AUTO-GENERATED
#
# Source: centralNodeReceiver.spd.xml
from ossie.resource import start_component
import logging

from centralNodeReceiver_base import *
#TODO
#Keep most current of each incoming node.  When all have changed/ enough time has passed send the requisite info to the updater
class centralNodeReceiver_i(centralNodeReceiver_base):
    """<DESCRIPTION GOES HERE>"""
    def constructor(self):
        self.port_message_in.registerMessage("accumMess", centralNodeReceiver_base.AccumMess, self.messageReceived)

    #make three parellel heaps sorted by time.  
    
    
    def messageReceived(self, msgId, msgData):
        self._log.info("messageReceived *************************")
        self._log.info("messageReceived msgId " + str(msgId))
        self._log.info("messageReceived msgData " + str(msgData)) 
          
    def process(self):
        testMsg= centralNodeReceiver_base.ToUpdate()
        testMsg.placeholder="fullCentNodeTest"
        self.port_message_out.sendMessage(testMsg)

        return NOOP

  
if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    logging.debug("Starting Component")
    start_component(centralNodeReceiver_i)

