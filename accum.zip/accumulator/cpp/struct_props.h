#ifndef STRUCTPROPS_H
#define STRUCTPROPS_H

/*******************************************************************************************

    AUTO-GENERATED CODE. DO NOT MODIFY

*******************************************************************************************/

#include <ossie/CorbaUtils.h>
#include <CF/cf.h>
#include <ossie/PropertyMap.h>

struct runningAve_struct {
    runningAve_struct ()
    {
    };

    static std::string getId() {
        return std::string("runningAve");
    };

    float ave;
    float aoa;
    float wavelength;
    float locLong;
    float locLat;
    float compass;
};

inline bool operator>>= (const CORBA::Any& a, runningAve_struct& s) {
    CF::Properties* temp;
    if (!(a >>= temp)) return false;
    const redhawk::PropertyMap& props = redhawk::PropertyMap::cast(*temp);
    if (props.contains("Ave")) {
        if (!(props["Ave"] >>= s.ave)) return false;
    }
    if (props.contains("AOA")) {
        if (!(props["AOA"] >>= s.aoa)) return false;
    }
    if (props.contains("Wavelength")) {
        if (!(props["Wavelength"] >>= s.wavelength)) return false;
    }
    if (props.contains("LocLong")) {
        if (!(props["LocLong"] >>= s.locLong)) return false;
    }
    if (props.contains("LocLat")) {
        if (!(props["LocLat"] >>= s.locLat)) return false;
    }
    if (props.contains("Compass")) {
        if (!(props["Compass"] >>= s.compass)) return false;
    }
    return true;
}

inline void operator<<= (CORBA::Any& a, const runningAve_struct& s) {
    redhawk::PropertyMap props;
 
    props["Ave"] = s.ave;
 
    props["AOA"] = s.aoa;
 
    props["Wavelength"] = s.wavelength;
 
    props["LocLong"] = s.locLong;
 
    props["LocLat"] = s.locLat;
 
    props["Compass"] = s.compass;
    a <<= props;
}

inline bool operator== (const runningAve_struct& s1, const runningAve_struct& s2) {
    if (s1.ave!=s2.ave)
        return false;
    if (s1.aoa!=s2.aoa)
        return false;
    if (s1.wavelength!=s2.wavelength)
        return false;
    if (s1.locLong!=s2.locLong)
        return false;
    if (s1.locLat!=s2.locLat)
        return false;
    if (s1.compass!=s2.compass)
        return false;
    return true;
}

inline bool operator!= (const runningAve_struct& s1, const runningAve_struct& s2) {
    return !(s1==s2);
}

#endif // STRUCTPROPS_H
