#ifndef UPDATER_I_IMPL_H
#define UPDATER_I_IMPL_H

#include "updater_base.h"

class updater_i : public updater_base
{
    ENABLE_LOGGING
    public:
        updater_i(const char *uuid, const char *label);
        ~updater_i();

        void constructor();

        int serviceFunction();
};

#endif // UPDATER_I_IMPL_H
