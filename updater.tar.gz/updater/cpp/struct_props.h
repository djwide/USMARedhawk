#ifndef STRUCTPROPS_H
#define STRUCTPROPS_H

/*******************************************************************************************

    AUTO-GENERATED CODE. DO NOT MODIFY

*******************************************************************************************/

#include <ossie/CorbaUtils.h>
#include <CF/cf.h>
#include <ossie/PropertyMap.h>

struct accum_struct {
    accum_struct ()
    {
    };

    static std::string getId() {
        return std::string("accum");
    };

    std::string avePower;
};

inline bool operator>>= (const CORBA::Any& a, accum_struct& s) {
    CF::Properties* temp;
    if (!(a >>= temp)) return false;
    const redhawk::PropertyMap& props = redhawk::PropertyMap::cast(*temp);
    if (props.contains("avePower")) {
        if (!(props["avePower"] >>= s.avePower)) return false;
    }
    return true;
}

inline void operator<<= (CORBA::Any& a, const accum_struct& s) {
    redhawk::PropertyMap props;
 
    props["avePower"] = s.avePower;
    a <<= props;
}

inline bool operator== (const accum_struct& s1, const accum_struct& s2) {
    if (s1.avePower!=s2.avePower)
        return false;
    return true;
}

inline bool operator!= (const accum_struct& s1, const accum_struct& s2) {
    return !(s1==s2);
}

#endif // STRUCTPROPS_H
