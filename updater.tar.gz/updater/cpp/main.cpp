#include <iostream>
#include "ossie/ossieSupport.h"

#include "updater.h"
int main(int argc, char* argv[])
{
    updater_i* updater_servant;
    Component::start_component(updater_servant, argc, argv);
    return 0;
}

