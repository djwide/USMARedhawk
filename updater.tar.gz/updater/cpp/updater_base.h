#ifndef UPDATER_BASE_IMPL_BASE_H
#define UPDATER_BASE_IMPL_BASE_H

#include <boost/thread.hpp>
#include <ossie/Component.h>
#include <ossie/ThreadedComponent.h>

#include "struct_props.h"

class updater_base : public Component, protected ThreadedComponent
{
    public:
        updater_base(const char *uuid, const char *label);
        ~updater_base();

        void start() throw (CF::Resource::StartError, CORBA::SystemException);

        void stop() throw (CF::Resource::StopError, CORBA::SystemException);

        void releaseObject() throw (CF::LifeCycle::ReleaseError, CORBA::SystemException);

        void loadProperties();

    protected:
        // Member variables exposed as properties
        /// Property: accum
        accum_struct accum;

    private:
};
#endif // UPDATER_BASE_IMPL_BASE_H
