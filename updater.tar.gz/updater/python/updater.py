#!/usr/bin/env python
#
#
# AUTO-GENERATED
#
# Source: updater.spd.xml
from ossie.resource import start_component
import logging
import math

from updater_base import *
#TODO
#Push proper updates to the dbwriter
class updater_i(updater_base):
    """<DESCRIPTION GOES HERE>"""
    def constructor(self):
        self.port_fromReceiver.registerMessage("toUpdate", updater_base.ToUpdate, self.messageReceived)
        self.xsize, self.ysize= 100, 100
        self.array= [[0 for x in range(self.xsize)] for y in range(self.ysize)]
        GPSLATBOTTOM= 1234.4321
        GPSLONGLEFT=1234.4321
        GPSLATTOP= 4321.1234
        GPSLONGRIGHT=4321.1234
        self.gpsxl=GPSLONGLEFT%1
        self.gpsyd= GPSLATBOTTOM%1
        self.gpsxr=GPSLONGRIGHT%1
        self.gpsyu= GPSLATTOP%1
        # TODO add customization here.
        
    def messageReceived(self, msgId, msgData):
        testMsg= updater_base.ToInsert()
        #update map function call
        testMsg.Data=str(msgData)
        self.port_toDB.sendMessage(testMsg)
            
    def process(self):
        # TODO fill in your code here
        return NOOP
    
    def gpsToArray(self, longi, lat):
        return (self.xsize*(longi-self.gpsxl)/(self.gpsxr-self.gpsxl))%1,(self.ysize*(lat-self.gpsyl)/(self.gpsyr-self.gpsyl))%1
    
    def pdoa(self):
        #receive message
        #unpack data
        #check timestamp
        #create 3 queues to hold data
        #p1,p2,p3= powerReadingsQueue.pop
        p1, p2, p3= 1,.1,.9
        alpha= 3 #2 to 4 where 2 is free space
        # distance ratios
        d12= pow(10, -(p1-p2)/(10*alpha))#p1 is unpacked power reading
        d23= pow(10, -(p2-p3)/(10*alpha))
        d31= pow(10, -(p3-p1)/(10*alpha))
        #print(d12)
        #print(d23)
        #print(d31)
        x1, x2,    x3, y1, y2, y3= 0,0,7,0,7,0# constants for GPS locations of sensors
        c1 = self.circleCenters(x1, y1, x2, y2, d12)
        #print(c1)
        c2 = self.circleCenters(x2, y2, x3, y3, d23)
        #print(c2)
        c3 = self.circleCenters(x3, y3, x1, y1, d31)
        #print(c3)
        rc1= self.radEqn(x1,y1,x2,y2,d12) 
        #print(rc1)
        rc2= self.radEqn(x2,y2, x3, y3, d23)
        #print(rc2)
        rc3= self.radEqn(x3, y3,x1,y1,d31)
        #print(rc3)
        for x in range(0, self.xsize):
            for y in range(0,self.ysize):
                self.array[x][y]= self.intensity((x,y), c1[0], c1[1],rc1)*self.intensity((x,y), c2[0], c2[1],rc2)*self.intensity((x,y), c3[0], c3[1],rc3)
        self.array[0][0]="OOOOO"
        self.array[0][7]="ypos"
        self.array[7][0]="xpos"
        return self.array
    
    #join methods for efficiency
    def radEqn(self,x1, y1, x2, y2, d):
        return pow(pow((x1-x2*d*d)/(d*d-1),2)+pow((y1-y2*d*d)/(d*d-1),2)-(d*d*x2*x2+d*d*y2*y2-x1*x1-y1*y1)/(d*d-1),.5)
    
    def circleCenters(self,x1, y1, x2, y2, d):
        return (x2*d*d-x1)/(d*d-1),(y2*d*d-y1)/(d*d-1)
    
    def distance(self, x0, y0, x1, y1): return math.sqrt((x0-x1)**2+(y0-y1)**2)
    

    def intensity(self,reading, x,y, distanceFromSource):
        return math.tanh(1/(.001+math.pow((distanceFromSource-self.distance(reading[0], reading[1],x,y)),2)))
    
    #merge with pdoa for efficiency
    def aoa(self):
        #receive message
        #unpack data
        #check timestamp
        #create 3 queues to hold data
        arraySum=0
        x1, x2,    x3, y1, y2, y3= .001,3.5,3.5,.001,6.999,0.001#constants
        aRead1, aRead2, aRead3= math.pi/4, -math.pi/2, math.pi/2
        for x in range(0, self.xsize):
            for y in range(0,self.ysize):
                #will have timestamp data
                #could index the below and only calculate once
                aActual1= self.angleSignTrans(y,y1,x,x1)
                aActual2= self.angleSignTrans(y,y2,x,x2)
                aActual3= self.angleSignTrans(y,y3,x,x3)
                readingCloseness1= (math.pi- self.radialDistance(aRead1,aActual1))/math.pi
                readingCloseness2= (math.pi- self.radialDistance(aRead2,aActual2))/math.pi
                readingCloseness3= (math.pi- self.radialDistance(aRead3,aActual3))/math.pi
                self.array[x][y]= readingCloseness1*readingCloseness2*readingCloseness3    
                arraySum+= self.array[x][y]
        self.array[0][0]="OOOOO"
        self.array[0][7]="ypos"
        self.array[7][0]="xpos"
        return self.array#normalize(arraySum, array)
    
    def angleSignTrans(self,y,yRead,x,xRead):
        if(y>yRead and x>xRead):
            return math.atan((y-yRead)/(x-xRead))
        elif(y>yRead and x<xRead):
            return math.pi+math.atan((y-yRead)/(x-xRead))
        elif(y<yRead and x>xRead):
            return math.atan((y-yRead)/(x-xRead))
        else:
            return -(math.pi-math.atan((y-yRead)/(x-xRead)))
        
    def radialDistance(self,x, y): #critical, acounts for discontinuiutes in arctan
        dist= math.fabs(x-y)%(2*math.pi)
        if(dist>math.pi): return 2*math.pi- dist
        return dist
    
    def normalize(self,totalP, array):
        for x in range(self.xsize):
            for y in range(self.ysize):
                array[x][y]=array[x][y]/totalP#relocate in the future
        #self.maxHMVal= self.maxHMVal/totalP
        return array
  
if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    logging.debug("Starting Component")
    start_component(updater_i)

