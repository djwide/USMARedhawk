/**************************************************************************

    This is the component code. This file contains the child class where
    custom functionality can be added to the component. Custom
    functionality to the base class can be extended here. Access to
    the ports can also be done from this class

**************************************************************************/

#include "PowerSensor.h"
#include <complex>
#include <cmath>
PREPARE_LOGGING(PowerSensor_i)

PowerSensor_i::PowerSensor_i(const char *uuid, const char *label) :
    PowerSensor_base(uuid, label)
{
    // Avoid placing constructor code here. Instead, use the "constructor" function.

}

PowerSensor_i::~PowerSensor_i()
{
}

void PowerSensor_i::constructor()
{
    /***********************************************************************************
     This is the RH constructor. All properties are properly initialized before this function is called
    ***********************************************************************************/
}


int PowerSensor_i::serviceFunction()
{

    bulkio::InFloatPort::dataTransfer *tmp = dataFloat->getPacket(bulkio::Const::BLOCKING);
    tmp -> SRI.mode=1;
    if (not tmp) { // No data is available
    	return NOOP;
    }
	std::vector<float> output;

	output.resize(tmp->dataBuffer.size()/2);

	std::vector<float>* intermediate = (std::vector<float>*) &(tmp->dataBuffer);
	for (unsigned int i=0; i<tmp->dataBuffer.size()/2; i++) {
		output[i]= (float) sqrt(pow((*intermediate)[2*i],2)+ pow((*intermediate)[2*i+1],2));
		LOG_DEBUG(PowerSensor_i, output[i]);
	}

	tmp -> SRI.mode=0;
	if (tmp->sriChanged) {
		dataFloat_1->pushSRI(tmp->SRI);
	}
	//no output need just message central node
	dataFloat_1->pushPacket(output, tmp->T, tmp->EOS, tmp->streamID);


	delete tmp; // IMPORTANT: MUST RELEASE THE RECEIVED DATA BLOCK
    return NORMAL;

}

